// import img1 from '../../images/biznes.png'
// import img2 from '../../images/it-and-comp-2.png'
// import img3 from './images/dizayn.png'

export const imagesArr=[
    "./images2/biznes.png"
]

